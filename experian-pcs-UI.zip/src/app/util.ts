import {Injectable} from '@angular/core';
import * as _ from 'underscore'; 
// import {SelectItem} from './common/modal/selectitem';

@Injectable()
export class Util {
    role : string = "";

      public showSignInLink(){
       let dom=document.getElementById('sigin-link');
       if(!_.isNull(dom))
         dom.setAttribute("style", "display:inline-block");
        else
         return;
    }
    public hideSignInLink(){
        let dom=document.getElementById('sigin-link');
        if(!_.isNull(dom))
           dom.setAttribute("style", "display:none");
        else
          return;
    }
    public clearLocalStorage()
    {
        localStorage.removeItem('currentUser');
        localStorage.removeItem('userName');
        localStorage.removeItem('authToken');
        localStorage.removeItem('role');        
        localStorage.removeItem('isAuthenticated'); 
        return;
    }
    public setRoleLable = ( currentUserRole ) => {
        let _self = this;
        _self.role = currentUserRole;
    }

    public getRoleLabel = () => {
        let _self = this;
        if(_.isEmpty(_self.role) || _self.role == '')
            return atob(localStorage.getItem("role"));
        else
            return _self.role;
    }
    
    public onFocus(targetVal:any,selectedDom:any,key:number)
    {
        let finalVal:any;
        
        let format:any = "dd/mm/yyyy";
        let match = new RegExp(format
                    .replace(/(\w+)\W(\w+)\W(\w+)/, "^\\s*($1)\\W*($2)?\\W*($3)?([0-9]*).*")
                    .replace(/d|m|y/g, "\\d"));
        let replace = "$1/$2/$3$4"
                    .replace(/\//g, format.match(/\W/));
        if( key == 8 || key == 46 )
        {
            return false;
        }
       else{ 
        finalVal=targetVal.replace(/(^|\W)(?=\d\W)/g, "$10")   // padding
                                    .replace(match, replace)             // fields
                                    .replace(/(\W)+/g, "$1").replace(/[^\0-9]/ig, ""); 
         selectedDom.querySelector(':focus').value=finalVal;
         selectedDom.querySelector(':focus').setAttribute("maxlength", "10");
        }
       
    }
    public equals(obj1: any, obj2: any, field?: string): boolean {
        if(field)
            return (this.resolveFieldData(obj1, field) === this.resolveFieldData(obj2, field));
        else
            return this.equalsByValue(obj1, obj2);
    }
    
    public equalsByValue(obj1: any, obj2: any): boolean {
        if (obj1 == null && obj2 == null) {
            return true;
        }
        if (obj1 == null || obj2 == null) {
            return false;
        }

        if (obj1 == obj2) {
            delete obj1._$visited;
            return true;
        }

        if (typeof obj1 == 'object' && typeof obj2 == 'object') {
            obj1._$visited = true;
            for (var p in obj1) {
                if (p === "_$visited") continue;
                if (obj1.hasOwnProperty(p) !== obj2.hasOwnProperty(p)) {
                    return false;
                }

                switch (typeof (obj1[p])) {
                    case 'object':
                        if (obj1[p] && obj1[p]._$visited || !this.equals(obj1[p], obj2[p])) return false;
                        break;

                    case 'function':
                        if (typeof (obj2[p]) == 'undefined' || (p != 'compare' && obj1[p].toString() != obj2[p].toString())) return false;
                        break;

                    default:
                        if (obj1[p] != obj2[p]) return false;
                        break;
                }
            }

            for (var p in obj2) {
                if (typeof (obj1[p]) == 'undefined') return false;
            }

            delete obj1._$visited;
            return true;
        }

        return false;
    }
    
    resolveFieldData(data: any, field: string): any {
        if(data && field) {
            if(field.indexOf('.') == -1) {
                return data[field];
            }
            else {
                let fields: string[] = field.split('.');
                let value = data;
                for(var i = 0, len = fields.length; i < len; ++i) {
                    if (value == null) {
                        return null;
                    }
                    value = value[fields[i]];
                }
                return value;
            }
        }
        else {
            return null;
        }
    }
    
    filter(value: any[], fields: any[], filterValue: string) {
        let filteredItems: any[] = [];
        
        if(value) {
            for(let item of value) {                
                for(let field of fields) {
                    if(String(this.resolveFieldData(item, field)).toLowerCase().indexOf(filterValue.toLowerCase()) > -1) {
                        filteredItems.push(item);
                        break;
                    }
                }
            }
        }
        
        return filteredItems;
    }
    
    reorderArray(value: any[], from: number, to: number) {
        let target: number;
        if(value && (from !== to)) {
            if(to >= value.length) {
                target = to - value.length;
                while((target--) + 1) {
                    value.push(undefined);
                }
            }
            value.splice(to, 0, value.splice(from, 1)[0]);
        }
    }
}