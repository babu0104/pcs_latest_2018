export class subtypeSystem {
    subTypeCode?: string;
    subTypeSys?: string;
    constructor() { }
}

export class subType {
    subTypeSystem?: subtypeSystem;
    subTypeDesc?: string;

    constructor() { }
}
export class bidCode {
    bidCode?: string;
    bidDesc?: string;

    constructor() { }
}
export class binCodeId {
    binCode?: string;
    binDesc?: string;

    constructor() { }
}
export class userId {
    userId?: string;

    constructor() { }
}
export class userBidBinSubmissionTypePk {
    userId?: userId;
    binCodeId?: binCodeId;
    bidCode?: bidCode;
    subType?: subType;


    constructor() { }
}
export class userBidBinSubmissionType {
    userBidBinSubmissionType?: Array<userBidBinSubmissionTypePk>;
    constructor() { }
}
export class roleDto {
    roleId?: string;
    roleDesc?: string;
    hierarchyValue?: string;
    constructor() { }
}

export class userCreateNode {
    userId?: string;
    firstName?: string;
    lastName?: string;
    phone?: string;
    email?: string;
    ics?: string;
    pcs?: string;
    secPhase?: string;
    secImg?: string;
    ipAddress?: string;
    roleDto?: roleDto;
    status?: string;
    userBidBinSubmissionType?: userBidBinSubmissionType;
    constructor() { }
}


