export class Role {
    ROLE : string;
    USER_ID : string;    
    FIRSt_NAME?: string;
    LAST_NAME?: string;
    IS_ACTIVE : boolean;
    CAN_ACTIVATE : boolean;
}