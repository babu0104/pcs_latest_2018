import { Routes, RouterModule } from '@angular/router';

import { MainComponent } from './shared/main/main.component';
import { FaqComponent } from './shared/faq/faq.component';
import { RulesComponent } from './shared/rules/rules.component';


import { HomePageComponent } from './components/home/home-page.component';
import { ManualEntryComponent } from './components/manual-entry/manual-entry.component';
import { ViewRecordsComponent } from './components/view-records/view-records.component';
import { PreferencesPageComponent } from './components/preferences/preferences-page.component';
import { FileUploadComponent } from './components/file-upload/file-upload.component';
import { UserAdminComponent } from './components/user-admin/user-admin.component';
import { ReceiveFilesComponent } from './components/receive-files/receive-files.component';

import { NotFoundComponent } from './shared/not-found/not-found.component';

//Manual Entry - individual forms
import { ManualEntryPrepaidEnrollmentComponent } from './components/manual-entry/manual-entry-submission-type/manual-entry-prepaid-enrollment/manual-entry-prepaid-enrollment.component';
import { ManualEntryDeclinedPrepaidEnrollmentComponent } from './components/manual-entry/manual-entry-submission-type/manual-entry-declined-prepaid-enrollment/manual-entry-declined-prepaid-enrollment.component';

import { LoadReloadComponent } from './components/manual-entry/manual-entry-submission-type/load-reload/load-reload.component';
import { ManualEntryProvisionalCreditRequestComponent } from './components/manual-entry/manual-entry-submission-type/manual-entry-provisional-credit-request/manual-entry-provisional-credit-request.component';
import { ManualEntryPrepaidInquiryComponent } from './components/manual-entry/manual-entry-submission-type/manual-entry-prepaid-inquiry/manual-entry-prepaid-inquiry.component';

import { ManualEntryPrepaidFraudComponent } from './components/manual-entry/manual-entry-submission-type/manual-entry-prepaid-fraud/manual-entry-prepaid-fraud.component';
import { ManualEntryDeleteComponent } from './components/manual-entry/manual-entry-submission-type/manual-entry-delete/manual-entry-delete.component';
import { ReportsPageComponent } from './components/reports/reports-page.component';
import { NewUserComponent } from './components/user-admin-createuser/new-user.component';
import { EditUserComponent } from './components/user-admin-edituser/edit-user.component';

//Login Authentication files
import { LoginComponent } from './shared/login/login.component';
import { PcsHomeComponent } from './components/pcs-home/pcs-home.component';
import { AuthGuard } from '../app/_guard/index';
import { AuthAnonymousGuard } from '../app/_guard/auth.anonymousguard';
import { LoaderComponent } from './shared/loader/loader.component';

export const routes: Routes = [
  { path: '', component: MainComponent, canActivate: [AuthAnonymousGuard] },
  { path: 'faq', component: FaqComponent },
  { path: 'rules', component: RulesComponent },
  { path: 'login', component: LoginComponent, canActivate: [AuthAnonymousGuard] },
  { path: 'pcs-home', component: PcsHomeComponent, canActivateChild: [AuthGuard],
      children: [
      // { path: '', redirectTo: 'pcs-home', pathMatch: 'full' },
        { path: 'home', component: HomePageComponent},
        { path: 'manual-entry', component: ManualEntryComponent,canActivateChild : [AuthGuard],
          children: [
            { path: '', pathMatch: 'full', redirectTo: 'ap' },
            { path: 'ap', component: ManualEntryPrepaidEnrollmentComponent,},
            { path: 'ap/:id', component: ManualEntryPrepaidEnrollmentComponent, },
            { path: 'dp', component: ManualEntryDeclinedPrepaidEnrollmentComponent, },
            { path: 'dp/:id', component: ManualEntryDeclinedPrepaidEnrollmentComponent, },
            { path: 'pr', component: LoadReloadComponent, },
            { path: 'pr/:id', component: LoadReloadComponent, },
            { path: 'pc', component: ManualEntryProvisionalCreditRequestComponent, },
            { path: 'pc/:id', component: ManualEntryProvisionalCreditRequestComponent, },
            { path: 'pi', component: ManualEntryPrepaidInquiryComponent, },
            { path: 'pi/:id', component: ManualEntryPrepaidInquiryComponent, },
            { path: 'pf', component: ManualEntryPrepaidFraudComponent, },
            { path: 'pf/:id', component: ManualEntryPrepaidFraudComponent, },
            { path: 'ad', component: ManualEntryDeleteComponent, },
            { path: 'ad/:id', component: ManualEntryDeleteComponent, },
          ]
        },
        { path: 'view-records', component: ViewRecordsComponent},
        { path: 'reports', component: ReportsPageComponent},
        { path: 'preferences', component: PreferencesPageComponent},
        { path: 'file-upload', component: FileUploadComponent},
        { path: 'user-admin', component: UserAdminComponent},
        { path: 'receive-files', component: ReceiveFilesComponent},
        { path: 'new-user', component: NewUserComponent},
        { path: 'edit-user', component: EditUserComponent}
      ]
  },
  //Not Found Redirection
  { path:'**', redirectTo: 'not-found'},
  { path: 'not-found', component: NotFoundComponent },
];
export const appRoutingProviders: any[] = [];
export const routing = RouterModule.forRoot(routes);
