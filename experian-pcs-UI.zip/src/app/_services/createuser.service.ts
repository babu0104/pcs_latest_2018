import { Injectable } from '@angular/core';
import { Http, Headers, RequestOptions, Response } from '@angular/http';
import { Observable } from 'rxjs';
import { Subject } from 'rxjs/Subject';
import 'rxjs/add/operator/map';
import * as _ from 'underscore';
import { bidCode, binCodeId, subtypeSystem, subType, userBidBinSubmissionTypePk,userCreateNode } from '../_models/createuser/createuserNode';

@Injectable()
export class CreateUserService {
    constructor(private http: Http) {}
    
    createBidTree(selectedBid,bidDesc)
    {
       let bincodeObj=new bidCode();
       bincodeObj.bidCode=selectedBid;
       bincodeObj.bidDesc=bidDesc;

       return bincodeObj;
    }
    createBinTree(selectedBin,binDesc)
    {
        
       let bincodeObj=new binCodeId();
       bincodeObj.binCode=selectedBin;
       bincodeObj.binDesc=binDesc;


       return bincodeObj;
    }
    createSubSystemTree(submissionCode, submissionSystem){
        let subtypeSystemObj=new subtypeSystem();
        subtypeSystemObj.subTypeCode=submissionCode;
        subtypeSystemObj.subTypeSys=submissionSystem;
        return subtypeSystemObj;
     }
     createSubType(subSystemNode,subtypeDesc){
       let subTypeObj=new subType();
       subTypeObj.subTypeSystem=subSystemNode;
       subTypeObj.subTypeDesc=subtypeDesc;
       return subTypeObj;
     }
     createfinalTree(bidNode,binNode,subTyeNode)
     {
         let binBidSubObj=new userBidBinSubmissionTypePk();
         binBidSubObj.bidCode=bidNode;
         binBidSubObj.binCodeId=binNode;
         binBidSubObj.subType=subTyeNode;
         return binBidSubObj;
     }  
     createUserNode(param,bidBinSubmissionArray,selectedRole,securityImageName)
     {
         let createuserObj=new userCreateNode();
         createuserObj.userId=param.userId;
         createuserObj.firstName=param.firstName;
         createuserObj.lastName=param.lastName;
         createuserObj.phone=param.phone;
         createuserObj.email=param.email;
         createuserObj.ics=param.ics ? "1" : "0";
         createuserObj.pcs=param.pcs ? "1" : "0";
         createuserObj.secPhase=param.secPhase;
         createuserObj.secImg=securityImageName;
         createuserObj.ipAddress=param.ipAddress;
         createuserObj.roleDto=selectedRole;
         createuserObj.status=(param.status === true) ? "1" : "0";
         createuserObj.userBidBinSubmissionType=bidBinSubmissionArray;
         return createuserObj;
 
     }  
}