import { Component } from '@angular/core';
import { UserLoginService } from './services/userLoginService';
import { LoginComponent } from './shared/login/login.component';
import { HeaderComponent } from './shared/header/header.component';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss'],
  providers: [UserLoginService]
})
export class AppComponent {
  loading: boolean = false;
  title = 'app';
  constructor() { }
    ngOnInit() {
  }
  displayloader() {
  this.loading = true;
}
hideloader() {
  this.loading = false;
}
}
