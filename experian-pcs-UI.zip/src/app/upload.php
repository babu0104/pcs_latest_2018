<?php echo '<p>Fake Upload Process</p>'; ?> 
