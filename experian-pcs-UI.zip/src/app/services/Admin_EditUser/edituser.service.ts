import { Injectable } from '@angular/core';
import { Http, Response } from '@angular/http';
import 'rxjs/Rx'

@Injectable()
export class EdituserService {
  posts: any[];
  constructor(private _http: Http) { }
getAllValue(){
  this._http.get('assets/data/edit_user.json')
  .subscribe(response => {
      this.posts = response.json();
  });
}
}
