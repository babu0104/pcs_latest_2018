import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import 'rxjs/add/operator/toPromise';
import { Observable } from 'rxjs/Observable';

@Injectable()
export class SSNValidateService {
    private _jsonResponse = '/../sampleResponse.json';
    formattedSSN : string = '';

    constructor(private _http: HttpClient, ) { }

    validateSSNService(ssnNumber) {
        var self = this;
        let val, len;
        try{
            if(ssnNumber){
                val = ssnNumber.toString().replace(/\D/g, "");
                len = val.length;
                    if( len < 4 ){
                        return len;
                    } else if ((3 < len && len < 6)){
                        return (val.substr(0, 3)) + "-" + (val.substr(3));
                    } else if( len > 5 ){
                        return (val.substr(0, 3)) + "-" + (val.substr(3, 2)) + "-" + (val.substr(5, 4));
                    }
                return this.formattedSSN = val;
            }         
        }
        catch(error){
            return Observable.throw(error.json().error || 'Server error');
        }
        
    }
}