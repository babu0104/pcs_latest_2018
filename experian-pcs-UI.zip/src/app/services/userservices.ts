import 'rxjs/add/operator/toPromise';

import { Http, Headers, RequestOptions, Response } from '@angular/http';
import { Injectable } from '@angular/core';

import { UserAdmin } from '../interfaces/user-admin';

import { Observable } from 'rxjs/Rx';
import { environment } from '../../environments/environment';

@Injectable()
export class UserService {
	private loggedInUserRoleId: any;
	private api: string;
	constructor(private http: Http) {
		this.api = environment.visaAdminUrl;
	 }

	setLoggedInUserRoleId(roleId) {
		this.loggedInUserRoleId = roleId;
	}

	getLoggedInUserRoleId() {
		return this.loggedInUserRoleId;
	}

	isUserExist(userId) {
		let body = { "userId": userId };
		return this.http.post(this.api+'/user/userId', body).map(res => res.json());
	}

	getUsers(loggedInUserRoleId, page, size, searchValue): Observable<any> {
		let data = { 'roleId': loggedInUserRoleId,'system':'PCS' };
		if (size === undefined) {
			return this.http.post(this.api+"/user/ListUser/page?page=" + page + "&size=&searchTerm=", data).map(res => res.json());
		} else {
			let search;
			if (searchValue === undefined) {
				search = "page=" + page + "&size=" + size + "&searchTerm=";
			} else {
				search = "page=" + page + "&size=" + size + "&searchTerm=" + searchValue;
			}
			return this.http.post(this.api+"/user/ListUser/page?" + search, data).map(res => res.json());
		}
	}
	getPreviewFiles(): Observable<any>{
		debugger;
		return this.http.get('assets/data/FileResponse/preview.json')
		.map((res: Response) => {
			return res.json();
		})
	}

	getUserRoleById(roleId,userAction): Observable<any> {
		let data = { 'roleId': roleId };
		return this.http.post(this.api+"/user/rolesbyId?action=" + userAction, data)
			.map(res => res.json())
			
	}
}
