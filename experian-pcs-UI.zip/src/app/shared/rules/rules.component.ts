import { Component, OnInit } from '@angular/core';
import { Inject } from '@angular/core';

@Component({
  selector: 'app-rules',
  templateUrl: './rules.component.html',
  styleUrls: ['./rules.component.scss'],
  providers: [
      { provide: Window, useValue: window }
  ],
})
export class RulesComponent implements OnInit {

  constructor(@Inject(Window) private window: Window) { }

  ngOnInit() {
  }
  
  scroll(el) {
    el.scrollIntoView();
  }

  toTop(){
    console.log('top');
    this.window.document.body.scrollIntoView();
  }
}
