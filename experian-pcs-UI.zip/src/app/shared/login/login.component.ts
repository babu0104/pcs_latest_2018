import { Component, OnInit ,ElementRef,ViewChild, Renderer} from '@angular/core';
import { PlatformLocation } from '@angular/common';
import { Router } from '@angular/router';
import { Http, Headers, RequestOptions, Response } from '@angular/http';
import { UserLoginService } from '../../services/userLoginService';
import { NgForm } from '@angular/forms';
import { AuthenticationService, Auth_UserService } from '../../_services/index';
import { User } from '../../_models/user';
import { AuthState } from '../../_models/authstate';
import * as _ from 'underscore';
import { Role } from '../../_models/Role';
import { Util } from '../../util'
import { CommonErrorComponent } from '../common-error/common-error.component';
import { environment } from '../../../environments/environment';
import { AppComponent } from '../../app.component';
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss'],
  providers: [Util],
})
export class LoginComponent implements OnInit {
 @ViewChild('myInput') input: ElementRef;
  model = new User();
  authState: AuthState;
  //loading = false;
  error = '';
  roleModel = new Role();
  backendErrorStatus: boolean = true;
  userName: any;
  isUserPresent: any;
  loginCancelled: boolean = false;
  private api: string;
  constructor(
    private http: Http,
    private router: Router,
    private userLoginService: UserLoginService, 
    private authenticationService: AuthenticationService, 
    private userService: Auth_UserService,
    private renderer: Renderer,
    private location: PlatformLocation,
    private utilObject: Util,
    private App : AppComponent
  ) {
    this.utilObject.hideSignInLink();
    this.api = environment.loginapiUrl;
  }


  ngOnInit() {
    let _self = this;
    this.userName = localStorage.getItem('userName');
    if(this.userName)
    {  
      this.renderer.invokeElementMethod(this.input.nativeElement, 'focus');
      let url = this.api+"/getImageOnUserId";
      let headers = new Headers({ 'Content-Type': 'application/json' });
      let options = new RequestOptions({ headers: headers });
      this.http.post(url, JSON.stringify({userId:this.userName}), options).subscribe(
        data => {
          if(!_.isNull(data)){
            let result = data.json();            
            this.model.secImage = _.isNull(result.imageName) ? '' : result.imageName;
            this.model.userName = _.isNull(result.userId) ? '': result.userId;
            this.model.secPhrase = _.isNull(result.secQuestion) ? '' : result.secQuestion;
          }
        },
        err => {
        }
      );
    }
    else
      this.router.navigate(['']);
  }
  PreventBack(){
    history.forward();
  }
  
  login() {
    let _self = this;
   _self.App.displayloader();
    //service to get username , pwd
    this.userService.validateUser(this.userName, this.model.password)
      .subscribe(result => {
        if ( result.isAuthenticated == true) {
          
            _self.router.navigate(['/pcs-home/home']);
            _self.App.hideloader();
        } else {
          this.error = 'Invalid UserName or Password';
          _self.App.hideloader();
        }
      });
  }
  passwordKeyDown(event) {
    if ((!_.isUndefined(event)) && event.keyCode == 13) {
      this.login();
    }
  }
  onCancel(event) {
    this.model.userName = '';
    this.utilObject.clearLocalStorage();
    this.router.navigate(['']);
  }
}

