export class SubmissionType {
    vin;
    BID: any;
}