export interface SecurityImage {
    imgname?;
    }