export interface UserAdmin {
	bidDesc;
	name;
	userID;
	role;
	service,
	created,
	modified,
	last_login,
	status;
}	