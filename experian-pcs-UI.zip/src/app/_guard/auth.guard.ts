import { Injectable } from '@angular/core';
import { Router, CanActivateChild } from '@angular/router';
import { AuthenticationService, Auth_UserService } from '../_services/index';
import { User } from '../_models/user';
import { Role } from '../_models/Role';
import * as _ from 'underscore';

@Injectable()
export class AuthGuard implements CanActivateChild {
    userModel = new User();
    roleModel = new Role();
    role: string;
    currentUserName: string;
    constructor(private router: Router, private auth: AuthenticationService, private userService: Auth_UserService) { }

    canActivateChild() {
        let authorisedUserModel = this.userService.getLoggedInUserDetails();
        this.role = _.isUndefined(authorisedUserModel) ? null : authorisedUserModel.role;
        if (authorisedUserModel.isAuthenticated == true) {
            let _self = this;
            let previousPath = _self.router.url;
            _self.userService.fetchPermittedPages(_self.role)
                .subscribe(result => {
                    if (result) {
                        let newRoutPath = _.isUndefined(_self.router) ? previousPath : _self.router.url;
                        var arrayres = _.filter(result[0].pages, function (urlVal) {
                            return urlVal == newRoutPath;
                        });
                        if (arrayres.length)
                            return true;
                        else
                            _self.router.navigate([result[0].default]);
                    }
                });
            // logged in so return true
            return true;
        } else {
            // not logged authenticated, redirect to login page
            this.router.navigate(['']);
            return false;
        }
    }
}