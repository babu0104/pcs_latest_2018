export class CreateUser {
    public firstName: string;
    public lastName: string;
    public userId: string;
    public phone: number;
    public email: string;
    public secPhase: string;
    public secImg: string;
    public ipAddress: number;
    public ics: string;
    public pcs: string;
    public roleDto: {
        roleId: string;
        roleDesc: string;
        hierarchyValue: string;
    };
    public userBidBinSubmissionMasterDto:{
        bid: string;
        binSubmissiontypeDto:Array<any>;
    }
    public defaultRoleDesc:string;
    public status: string;
    public lastModifiedDate: string;
    public lastLoginDate: string;
    public usercreationDate: string;
    public selected1: number;
    public selected2: number;
    public selected3: number;
    
    public bidCode: number;
    public bidDesc: string;
    public subTypeCode: number;
    public subTypeSys: string;
    public subTypeDesc: string;
   
    constructor() { }
}