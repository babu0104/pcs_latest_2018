import { Component, OnInit,TemplateRef } from '@angular/core';
import { BsModalRef, BsModalService } from 'ngx-bootstrap/modal';
import { PickListModule } from 'primeng/primeng';
import { templateOptionProvider } from '../../services/templateoptionprovider.serivce';

import {User} from '../../interfaces/user';
import {UserService} from '../../services/userservices';

import { fileUpload } from './fileupload.modal'; //Modal for file upload page

@Component({
  selector: 'app-file-upload',
  templateUrl: './file-upload.component.html',
  styleUrls: ['./file-upload.component.scss'],
  providers : [templateOptionProvider],
})
export class FileUploadComponent implements OnInit {
  
  uploadedFiles: any[] = [];

  sourceOption: any [];
  targetOption: any [];

  isFileTypeChanged : boolean;
  isCustomSubmissionChanged : boolean;
  SelectedFileType : string;

  public modalRef: BsModalRef;

  fileUploadData : fileUpload; 
  previewFiles:fileUpload[];
  selectedType: string[] = ['RETRO'];

  selectedDevice: string = "PCS968";
  validCount:number;
  invalidCount:number;
  submissionType:string="AP";

  showFilePreview: boolean = true;
  showManualEntryForm: boolean = false;

  onUpload(event) {
      for(let file of event.files) {
          this.uploadedFiles.push(file);
      }
  }

  constructor(private modalService: BsModalService, private _templateOptionProvider : templateOptionProvider,private userService: UserService ) {
      this.fileUploadData =  new fileUpload();
   }

  ngOnInit() {    
    this.validCount=0;
    this.invalidCount=0;
    this.previewFiles=[];
    //assign false by default
    this.isCustomSubmissionChanged = false;
    this.fileUploadData.layout = '-1';
    console.log(this.isCustomSubmissionChanged + 'onload');
    setTimeout(() => {
      this.sourceOption = this._templateOptionProvider.getAllOptions();
      console.log(this.sourceOption);
    }, 1000);

    this.targetOption = [];

    //this.renderSelectOption(event);
  }
  clearAll(e){
    this.fileUploadData.clear();

  }
  public openModal(template: TemplateRef<any>) {
    this.modalRef = this.modalService.show(template);
  }
  
  onFileTypeChange(event){
    let _self = this;
    let selected = event.currentTarget.value;
    if(selected.toLowerCase() == 'custom'){
      this.isFileTypeChanged = true;
      this.SelectedFileType = selected;
    } else{
      this.isFileTypeChanged = false;
      this.SelectedFileType = selected;
    }
    this.isCustomSubmissionChanged = true;
    console.log(this.isCustomSubmissionChanged + 'onchange');
  }

  onFixedWidthChage(event){
    console.log(event);
  }
  oncommaDelimeterChange(event){
    console.log(event);
  }
  onSubmissionTypeChange(event){
    this.isCustomSubmissionChanged = true;
  }

  onSelectCustomTemplate(event){
    let self = this;

  }

  setSelectTemplateDisabled(e){
    let self = this;
    console.log('disbaling');
    document.getElementById('select-template').setAttribute('disabled', 'disabled');
  }

  renderSelectOption($event){
    
  }
  closeModal(id: number)
  {
    this.modalService.hide(id);
  }
  upload(previewFile: TemplateRef<any>)
  {
    this.showFilePreview = true;
    this.showManualEntryForm = false;
    this.modalRef = this.modalService.show(previewFile,{class: 'modal-lg'});
    this.userService.getPreviewFiles().subscribe(res => {
        this.previewFiles=res.FilePreviews;
        for (let i = 0; i < this.previewFiles.length; i++) {
          if(this.previewFiles[i]['status']=="invalid")
          {
            this.invalidCount++;
          }
          if(this.previewFiles[i]['status']=="valid")
          {
            this.validCount++;
          }
      }

    });
  }
  isRowValid(rowData: any) {
    return (rowData.status=="invalid") ? "danger" : "";
  } 
  rowclick=(event)=>{
    if(event.data.status=="invalid")
    {
      this.showFilePreview = !this.showFilePreview;
      this.showManualEntryForm = !this.showManualEntryForm;
      this.submissionType=event.data.subType.subTypeSystem.subTypeCode;
    }
    
  }
  goToPreview(event)
  {
    this.showFilePreview = !this.showFilePreview;
    this.showManualEntryForm = !this.showManualEntryForm;
  }

}
