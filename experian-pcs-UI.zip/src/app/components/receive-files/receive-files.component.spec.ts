import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ReceiveFilesComponent } from './receive-files.component';

describe('ReceiveFilesComponent', () => {
  let component: ReceiveFilesComponent;
  let fixture: ComponentFixture<ReceiveFilesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ReceiveFilesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ReceiveFilesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
