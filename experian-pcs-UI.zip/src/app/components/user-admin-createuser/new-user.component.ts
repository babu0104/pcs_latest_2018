import { Component, Directive, forwardRef, Attribute, OnChanges, SimpleChanges, Input, OnInit, TemplateRef } from '@angular/core';
import { NG_VALIDATORS, Validator, Validators, AbstractControl, ValidatorFn } from '@angular/forms';
import { Router } from '@angular/router';
import { Headers, Response, RequestOptions, URLSearchParams, Http } from '@angular/http';
import { BsModalRef, BsModalService } from 'ngx-bootstrap/modal';
import { SecurityImage } from '../../interfaces/user-admin-images';
import { UserAdmin } from '../../interfaces/user-admin';
import { UserService } from '../../services/userservices';
import { CreateUser } from '../../create-user';
import { userRoleService } from '../../services/user-roles-services';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import * as _ from 'underscore';
import { Message } from 'primeng/components/common/api';
import { MessageService } from 'primeng/components/common/messageservice';

import { DatePipe } from '@angular/common';
//import { SubmissionType } from '../../interfaces/admin_preferences/submissiontype';
import { CreateUserService } from '../../_services/createuser.service';
import { AppComponent } from '../../app.component';
import * as $ from 'jquery';
//import * as _ from 'lodash'; 
import { environment } from '../../../environments/environment';



@Component({
  moduleId: module.id,
  selector: 'app-new-user',
  templateUrl: './new-user.component.html',
  styleUrls: ['./new-user.component.scss'],
  providers: [userRoleService, MessageService]
})


export class NewUserComponent implements OnInit {
  //bidvalues: SubmissionType[];
  selectedBin = [];
  bidvalues = [];
  allowedSubmissionType = [];
  showBins: boolean;
  showSubmission: boolean;
  allowedBins = [];
  msgs: Message[] = [];
  commonError: boolean;
  images: any[];
  public modalRef: BsModalRef;
  securityImageUrl: any;
  selectedImageUrl: any;
  showUserAdmin: boolean = false;
  showNewUser: boolean = true;
  loading: boolean;
  users: any[];
  cols: any[];
  roles: any[];
  bids: any[];
  submissiontypes: any[];
  selectedBids: any[];
  selectedBins: any[];
  selectedSubmitTypes: any[];
  createuser = new CreateUser();
  userRoles: any;
  selectedRole: any;
  loggedInUserRoleId: string;
  currentBin: number;
  binList = [];
  inArr = [];
  subTypes = [];
  showSubm: boolean;
  sortOrder: string = 'asc';
  sortItem: string = '';

  hierarchy = [];
  filteredData = [];
  date: string;
  filteredBids: any[];
  bin: string;

  bidNode = {};
  binNode = {};
  subSystemNode = {};
  subTyeNode = {};
  submissionTypePkNode = {};
  createuserNode = {};
  subNode = {};
  selectedValues: string[] = [];
  bidBinSubmissionArray = [];
  private api: string;
  securityImageName:string;
  successmsg: boolean = false;
  constructor(private router: Router,
    private modalService: BsModalService,
    private userService: UserService,
    private http: Http,
    private userRoleService: userRoleService,
    private messageService: MessageService,
    private createUserService: CreateUserService,
    private App : AppComponent
  ) {
    this.api = environment.visaAdminUrl;
    this.images = [
      { imgname: '1' }, { imgname: '3' }, { imgname: '4' }, { imgname: '5' }, { imgname: '6' },
      { imgname: '7' }, { imgname: '8' }, { imgname: '9' }, { imgname: '10' }, { imgname: '11' },
      { imgname: '12' }, { imgname: '13' }, { imgname: '14' }, { imgname: '15' },
      { imgname: '16' }, { imgname: '17' }, { imgname: '18' }, { imgname: '19' }, { imgname: '20' },
      { imgname: '21' }, { imgname: '22' }, { imgname: '23' }, { imgname: '24' }, { imgname: '25' },
      { imgname: '26' }, { imgname: '27' }, { imgname: '28' }, { imgname: '29' }
    ];

    this.date = 'currentDate'

    let dp = new DatePipe('de-DE' /* locale .. */);
    this.date = dp.transform(new Date(), 'dd-MM-yyyy');
    $(document).on("click", ".toggle", function (e) {
      e.preventDefault();
    
      var $this = $(this);
    
      if ($this.next().hasClass('show')) {
          $this.next().removeClass('show');
          //$this.next().slideUp(350);
      } else {
          $this.parent().parent().find('li .inner').removeClass('show');
          //$this.parent().parent().find('li .inner').slideUp(350);
          $this.next().toggleClass('show');
          //$this.next().slideToggle(350);
      }
      e.stopImmediatePropagation();
  });

  }
    ngOnInit() {

      
      $(document).on("click", ".child", function () {
        let $parent;
        $parent = $(this).parents("li").find('.parent');
        if ($(this).is(":checked")){
          $parent.prop("checked", true);
        } 
        else {
          var len = $(this).parents("li").find(".child:checked").length;
          $parent.prop("checked", len > 0);
        }
      });
      $(document).on("click", ".checkmark", function (event) {
        $(this).each(function(){
          if ($(this).prev('input.parent').is(':checked'))
          {
            $(this).prev().prop("checked", false);
            $(this).closest('li').find('input:checkbox').prop("checked", false);
          }
          else{
            $(this).prev('input.parent').prop("checked", true);
          }
          
          event.stopImmediatePropagation();
        });
      });
      this.commonError = false;
      this.loading = true;
      this.createuser.ics = "0";
      this.createuser.pcs = "0";
      this.getuserrole();
  }

  filterBins(event) {
    let getbid = event.query;
    setTimeout(() => {
      this.userRoleService.getSubmission(getbid).subscribe(res => {
        this.bidvalues = res;
      });
      
      this.loading = false;
    }, 1000);

    this.filteredBids = [];
    for (let i = 0; i < this.bidvalues.length; i++) {
      let bidvalue = this.bidvalues[i].bidCode;
      if (bidvalue.toLowerCase().indexOf(event.query.toLowerCase()) == 0) {
        this.filteredBids.push(bidvalue);
      }
    }
  }
  getuserrole() {
    //this.loggedInUserRoleId = this.userService.getLoggedInUserRoleId();
    this.loggedInUserRoleId = "VA";
    let userAction = "create";
    this.userRoleService.getuserrole(this.loggedInUserRoleId, userAction).subscribe(res => {
      this.roles = res;
      this.userRoles = this.roles;
    });
  }


  //select image
  backToUserAdmin() {
    this.showUserAdmin = !this.showUserAdmin;
    this.showNewUser = !this.showNewUser;
  }

  selectImage(image: any) {
    this.selectedImageUrl.setAttribute('src', image.src);
  }

  setImage() {
    this.securityImageUrl.setAttribute('src', this.selectedImageUrl.getAttribute('src'));
    this.securityImageName = this.securityImageUrl.getAttribute('src').substring(this.securityImageUrl.getAttribute('src').lastIndexOf('/')+1);
    this.closeModal();
  }

  public openModal(template: TemplateRef<any>) {
    this.modalRef = this.modalService.show(template);


    // this.userRoleService.getAllImages().subscribe(res => {
    //   this.images = res;
    // });


    this.securityImageUrl = document.getElementById('security-image');
    this.selectedImageUrl = document.getElementById('selected-image');

    this.selectedImageUrl.setAttribute('src', this.securityImageUrl.getAttribute('src'));
  }

  public closeModal() {
    this.modalRef.hide();
  }

  // form submit
  submitted = false; //form not submited : default
  data: any; //this variable contains our data

  //Show data after form submit and set submitted to true
  onSubmit(data) {
    this.submitted = true;
    this.createUser(data);
  }
  createUser(param)
  {
    let _self = this;
    _self.App.displayloader();
    this.bidBinSubmissionArray=[];
    this.selectedRole = this.userRoles.filter(function (node) {
      return node.roleDesc == param.roleDesc;
    });
    
    let binNodes;
    let finalArray
    $('input.parent:checked').each(function() {
      let checkedbin=$(this).val();
      binNodes=_self.formbin(checkedbin);
      $(this).closest('li').find('input.child:checked').each(function(){
        let str = $(this).val();
        let str_array = str.split('-');

        let subtypeCode = str_array[0];
        let subtypeDesc = str_array[1];
        let subTypeSys = str_array[2];

        finalArray=_self.formSubType(subtypeCode, subTypeSys, subtypeDesc,binNodes);
       
      });
    });
   
      this.createuserNode = this.createUserService.createUserNode(param, this.bidBinSubmissionArray, this.selectedRole[0],this.securityImageName);
      //console.log(this.createuserNode);
    
     let headers = new Headers({ 'Content-Type': 'application/json' });
     let options = new RequestOptions({ headers: headers });
 
     this.http.post(this.api +'/user/createUser', JSON.stringify(this.createuserNode), options).subscribe(
     
      data => {
        _self.App.hideloader();
         this.showSuccess();
       },
       err => {
        _self.App.hideloader();
         this.showError();
       }
     );
  }
  showSuccess() {
    this.msgs = [];
    this.successmsg = true;
    //this.msgs.push({ severity: 'success', summary: 'Success!', detail: 'User created successful' });
  }

  showError() {
    this.msgs = [];
    this.msgs.push({ severity: 'error', summary: 'Error!', detail: 'User created failed' });
  }

  onRowSelect(event: any) {
    let _self = this;
    _self.showBins = true;
    _self.showSubmission = false;
    let bId = event;
    let binListArray = _self.getBins(bId);
    //this.binList pushhhh
    if (_.isArray(binListArray) && !_.isUndefined(binListArray)) {
     
    } else {
      // alert("Error Occured while fetching Bin");
    }
      }
      formbin(bin) {
        let selectedBin = (_.isUndefined(bin) || _.isNull(bin)) ? null : bin;
        this.binNode = this.createUserService.createBinTree(selectedBin, null);
        return this.binNode;
    }
    getBins(bid) {
      var _self = this;
      let selectedBid = (_.isUndefined(bid) || _.isNull(bid)) ? null : bid;
      _self.bidNode = this.createUserService.createBidTree(selectedBid, null);
  
      _self.userRoleService
        .getBinList(selectedBid)
        .subscribe(res => {
          this.binList = res;
        });
    }
    formSubType(subtypeCode, subTypeSys, subtypeDesc, currentBinNode) {
      let submissionCode = (_.isUndefined(subtypeCode) || _.isNull(subtypeCode)) ? null : subtypeCode;
      let submissionSystem = (_.isUndefined(subTypeSys) || _.isNull(subTypeSys)) ? null : subTypeSys;
      this.subSystemNode = this.createUserService.createSubSystemTree(submissionCode, submissionSystem);
      this.subTyeNode = this.createUserService.createSubType(this.subSystemNode, subtypeDesc);
      this.submissionTypePkNode = this.createUserService.createfinalTree(this.bidNode, currentBinNode, this.subTyeNode);
      this.subNode = { "userBidBinSubmissionTypePk": this.submissionTypePkNode };
      this.bidBinSubmissionArray.push(this.subNode);
      return this.bidBinSubmissionArray;
    }
    gotoList(){
      //debugger;
      this.showNewUser = !this.showNewUser;
      this.showUserAdmin = !this.showUserAdmin;
      this.successmsg=false;
      //this.router.navigate(['../ics-home/user-admin']);
    }
  }
