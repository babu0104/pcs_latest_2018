import { Component, OnInit } from '@angular/core';
import { Http, Headers, RequestOptions, Response } from '@angular/http';
import { User } from '../../_models/index';
import { Auth_UserService } from '../../_services/index';

@Component({
  selector: 'app-home-page',
  templateUrl: './home-page.component.html',
  styleUrls: ['./home-page.component.scss'],
  providers: [Auth_UserService],
})
export class HomePageComponent implements OnInit {
  model: any = User;

  constructor(private userService : Auth_UserService) { 
    
  }

  ngOnInit() {
    
  }

}
