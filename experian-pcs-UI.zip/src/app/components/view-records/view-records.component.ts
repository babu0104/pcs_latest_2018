import { Component, OnInit } from '@angular/core';
import {CalendarModule} from 'primeng/primeng';
import {User} from '../../interfaces/user';
import {UserService} from '../../services/userservices';
import { Router } from '@angular/router';
declare var $: any
@Component({
  selector: 'app-view-records',
  templateUrl: './view-records.component.html',
  styleUrls: ['./view-records.component.scss']
})
export class ViewRecordsComponent implements OnInit {
  title = 'app';
  loading: boolean;
   users: User[];
	 cols: any[];
	 phonenumber1: string;
	 ssnNumber: string;
  
search() {
  let records = document.getElementsByClassName('record-table');
  records[0].classList.add('display-table');
}
  constructor(private userService: UserService, private router: Router) {}
	onCancel(event){
		this.router.navigate(['/pcs-home/home']);
	}
    	ngOnInit() {
		  this.loading = true;
			// setTimeout(() => {
			// 	this.userService.getUsers().subscribe(users => this.users = users);
			// 	console.log(this.users);
			// 	this.loading = false;
      // }, 1000);
			
			this.cols = [
				{field: 'vin', header: 'Vin'},
				{field: 'year', header: 'Year'},
				{field: 'brand', header: 'Brand'},
				{field: 'color', header: 'Color'}
			];
		}

}
