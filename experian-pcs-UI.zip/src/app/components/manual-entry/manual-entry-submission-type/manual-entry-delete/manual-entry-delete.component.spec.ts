import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ManualEntryDeleteComponent } from './manual-entry-delete.component';

describe('ManualEntryDeleteComponent', () => {
  let component: ManualEntryDeleteComponent;
  let fixture: ComponentFixture<ManualEntryDeleteComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ManualEntryDeleteComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ManualEntryDeleteComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
