import { Component, OnInit, ElementRef, Directive, forwardRef, Attribute, OnChanges, SimpleChanges, Input } from '@angular/core';
import { NG_VALIDATORS, Validator, Validators, AbstractControl, ValidatorFn } from '@angular/forms';
import { Util } from '../../../../util';
import { User } from '../../../../User';
import { Router } from '@angular/router';
declare var $: any

@Component({
  selector: 'app-manual-entry-delete',
  templateUrl: './manual-entry-delete.component.html',
  styleUrls: ['./manual-entry-delete.component.scss']
})
export class ManualEntryDeleteComponent implements OnInit {
  utilObject : Util;
  value: Date;
  phonenumber1: string;
  phonenumber2: string;
  user = new User();
  constructor(private elRef: ElementRef, private router: Router) {
    this.utilObject = new Util();
  }
  ngOnInit() {
  }
  onCancel(event) {
    this.router.navigate(['/pcs-home/home']);
  }


  onFormClearAll() {

  }


}