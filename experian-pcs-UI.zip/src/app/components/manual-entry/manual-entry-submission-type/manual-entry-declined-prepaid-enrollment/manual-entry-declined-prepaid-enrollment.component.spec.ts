import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ManualEntryDeclinedPrepaidEnrollmentComponent } from './manual-entry-declined-prepaid-enrollment.component';

describe('ManualEntryDeclinedPrepaidEnrollmentComponent', () => {
  let component: ManualEntryDeclinedPrepaidEnrollmentComponent;
  let fixture: ComponentFixture<ManualEntryDeclinedPrepaidEnrollmentComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ManualEntryDeclinedPrepaidEnrollmentComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ManualEntryDeclinedPrepaidEnrollmentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
