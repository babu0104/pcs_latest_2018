import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ManualEntryPrepaidEnrollmentComponent } from './manual-entry-prepaid-enrollment.component';

describe('ManualEntryPrepaidEnrollmentComponent', () => {
  let component: ManualEntryPrepaidEnrollmentComponent;
  let fixture: ComponentFixture<ManualEntryPrepaidEnrollmentComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ManualEntryPrepaidEnrollmentComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ManualEntryPrepaidEnrollmentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
