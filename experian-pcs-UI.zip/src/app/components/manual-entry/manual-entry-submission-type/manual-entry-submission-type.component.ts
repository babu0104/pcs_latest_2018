import { Component, OnInit } from '@angular/core';
import { MessageService } from '../../../services/message.service';

@Component({
  moduleId: module.id,
  selector: 'app-manual-entry-submission-type',
  templateUrl: './manual-entry-submission-type.component.html',
  styleUrls: ['./manual-entry-submission-type.component.scss']
})
export class ManualEntrySubmissionTypeComponent implements OnInit {
 public defaultselect:string="Prepaid Enrollment";
  constructor(private messageService: MessageService) { 
     messageService.sendMessage(this.defaultselect)
  }

  ngOnInit() {
  }
   setradio(radioButtonValue: string): void {
     this.messageService.sendMessage(radioButtonValue);
  }
}
