/** 
 * This modal(class) contains the methods and properties for manual entry header
 * will be used across all the submission type which includes this header
 * this model extends by individual submission type modals to have data collectively
 * for more info please refere file upload module
 **/
export class manualEntryHeader {
    bid : number;
    service : string;
    bin : number;
    mso : string;
    locatorNumber : number;
    // locatorNumber ?: number;  //can not be a mandatory

}