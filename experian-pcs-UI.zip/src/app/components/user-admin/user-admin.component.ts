import { Component, OnInit, ViewChild } from '@angular/core';
import { User } from '../../interfaces/user';
import { UserService } from '../../services/userservices';
import { Router } from '@angular/router';
import { LazyLoadEvent, SelectItem, DataTable } from 'primeng/primeng';
import { Auth_UserService } from '../../_services/user.service';
import { AppComponent } from '../../app.component';
import {HeaderComponent} from '../../shared/header/header.component';
@Component({
  selector: 'app-user-admin',
  templateUrl: './user-admin.component.html',
  styleUrls: ['./user-admin.component.scss'],
  providers: [HeaderComponent]
})
export class UserAdminComponent implements OnInit {
  title = 'app';
  users: User[];
  cols: any[];
  showNewUser: boolean = false;
  showUserAdmin: boolean = true;
  showEditUser: boolean = false;
  userStatus: SelectItem[];
  selectedStatus: boolean;
  datasource: User[];
  status: string;
  searchResult: User[];
  userDetail: any;
  searchValue: string;
  loggedInUserRoleId: string;
  totalRecords: number;
  @ViewChild('dt') userTable: DataTable;

  constructor(private userService: UserService, private router: Router,private user_Service:Auth_UserService, 
    private App : AppComponent, private headerComp : HeaderComponent) {
    this.userStatus = [
      { label: 'All', value: null },
      { label: 'Inactive', value: 'Inactive' }
    ];
    setTimeout(() => {
      this.headerComp.ngAfterViewInit(); 
    },500)
  }

  editUser(userId) {
    this.showEditUser = !this.showEditUser;
    this.showUserAdmin = !this.showUserAdmin;

    this.userDetail = this.users.filter(function (node) {
      return node.userId == userId;
    });
  }

  createNewUser() {
    this.showNewUser = !this.showNewUser;
    this.showUserAdmin = !this.showUserAdmin;
  }

  ngOnInit() {
    // let _self = this;
    // _self.App.displayloader();
    this.loggedInUserRoleId = this.user_Service.getLoggedInUserDetails().role;
    let page = 0, size, searchValue;
    this.userService.getUsers(this.loggedInUserRoleId, page, size, searchValue).subscribe(res => {
      this.datasource = res.baseDtoList;
      this.totalRecords = res.countOfRecords;
      this.users = this.datasource;
      setTimeout(() => {
        this.headerComp.ngAfterViewInit(); 
      },1000)
      //_self.App.hideloader();
    });
    
    
    this.cols = [
      { field: 'name', header: 'Name' },
      { field: 'userId', header: 'userId' },
      { field: 'userRole', header: 'role', nested: true },
      { field: 'service', header: 'service' },
      { field: 'created', header: 'created' },
      { field: 'modified', header: 'modified' },
      { field: 'last_login', header: 'last_login' },
      { field: 'status', header: 'status' }
    ];
    
  }

  loadUsersLazy(event: LazyLoadEvent) {
    if (this.datasource != undefined) {
      let self = this;
      let page = (event.first / event.rows);
      this.userService.getUsers(this.loggedInUserRoleId, page, event.rows, this.searchValue).subscribe(res => {
        let self = this;
        self.searchResult = res.baseDtoList;
        self.totalRecords = res.countOfRecords;
        self.datasource = self.searchResult;
        self.users = self.datasource;
        self.userTable.updateDataToRender(self.users);
      });
    }
  }
  handleInactiveUser(event) {
    let checked = event.currentTarget.checked;
    this.selectedStatus = checked ? true : false;
  }
  checkInputValue(event) {
    if (event.keyCode === 13) { // if user press enter
      this.userTableGlobalFilter(this.searchValue, this.userTable);
    } else {
      return;
    }
  }
  userTableGlobalFilter(searchValue, userTable) {
    this.searchValue = searchValue;
    userTable.reset();
  }
}


