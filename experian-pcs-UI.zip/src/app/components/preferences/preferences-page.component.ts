import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
declare var $: any


@Component({
  selector: 'app-preferences-page',
  templateUrl: './preferences-page.component.html',
  styleUrls: ['./preferences-page.component.scss']
})
export class PreferencesPageComponent implements OnInit {

  constructor(private router: Router) { }
    onCancel(event){
		this.router.navigate(['/pcs-home/home']);
	}
  ngOnInit() {
  }

}
