import { VisaUsingScssPage } from './app.po';

describe('visa-using-scss App', () => {
  let page: VisaUsingScssPage;

  beforeEach(() => {
    page = new VisaUsingScssPage();
  });

  it('should display welcome message', () => {
    page.navigateTo();
    expect(page.getParagraphText()).toEqual('Welcome to app!!');
  });
});
